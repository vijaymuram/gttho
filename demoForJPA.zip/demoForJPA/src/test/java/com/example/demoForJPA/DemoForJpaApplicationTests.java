package com.example.demoForJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoForJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
