package com.example.demoForJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoForJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoForJpaApplication.class, args);
	}

}
